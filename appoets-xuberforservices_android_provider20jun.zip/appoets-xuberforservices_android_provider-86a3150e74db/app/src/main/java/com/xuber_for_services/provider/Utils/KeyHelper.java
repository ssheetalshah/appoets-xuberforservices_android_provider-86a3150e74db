package com.xuber_for_services.provider.Utils;

/**
 * Created by RAJKUMAR on 17-05-2017.
 */

public class KeyHelper {
    public static final String KEY_FIRST_NAME = "first_name";
    public static final String KEY_AVATAR = "avatar";
    public static final String KEY_ACCESS_TOKEN = "access_token";
}
