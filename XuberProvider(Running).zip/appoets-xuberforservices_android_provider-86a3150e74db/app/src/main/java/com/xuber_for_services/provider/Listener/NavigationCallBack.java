package com.xuber_for_services.provider.Listener;

/**
 * Created by arajkumar on 10-04-2017.
 */
public interface NavigationCallBack {
    public void handleNavigationDrawer();

    public void enableDisableNavigationDrawer(boolean isEnable);
}
